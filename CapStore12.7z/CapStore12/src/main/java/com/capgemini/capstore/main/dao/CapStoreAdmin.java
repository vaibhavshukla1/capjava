package com.capgemini.capstore.main.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.main.beans.Admin;
@Repository
@Transactional
public interface CapStoreAdmin extends JpaRepository<Admin, Integer>{

}
