package com.capgemini.capstore.main.service;

import com.capgemini.capstore.main.beans.Order;

public interface CapstoreCustomerService {
	public boolean generateReturnRequest(Order order);
}
