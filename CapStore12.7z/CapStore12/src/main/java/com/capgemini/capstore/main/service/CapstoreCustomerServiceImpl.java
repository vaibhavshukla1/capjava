package com.capgemini.capstore.main.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.DeliveryStatus;
import com.capgemini.capstore.main.beans.Order;
import com.capgemini.capstore.main.beans.ReturnRequest;
import com.capgemini.capstore.main.beans.ReturnStatus;
import com.capgemini.capstore.main.dao.CapStoreCustomer;
import com.capgemini.capstore.main.dao.CapStoreReturnRequest;

@Transactional
@Service
public class CapstoreCustomerServiceImpl implements CapstoreCustomerService {
	
	@Autowired
	CapStoreReturnRequest capstoreReturnRequest;
	
	@Autowired
	CapStoreCustomer capstoreCustomer;

	@Override
	public boolean generateReturnRequest(Order order) {
		if(order.getDeliveryStatus()==DeliveryStatus.Delivered)
		{
			ReturnRequest returnRequest = new ReturnRequest();
			returnRequest.setReturnStatus(ReturnStatus.Applied);
			capstoreReturnRequest.save(returnRequest);
			return true;
		}
		else
		{
			return false;
		}
	}
}