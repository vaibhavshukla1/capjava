package com.capgemini.capstore.beans;

public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics
}
