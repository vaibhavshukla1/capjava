package com.capgemini.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.service.CustomerReturnProductImpl;

@RestController
public class Controller {
	
	@Autowired
	CustomerReturnProductImpl returnproduct;
	
	@RequestMapping(value = "/generateReturnRequest", method = RequestMethod.POST)
	public boolean generateReturnRequest(@RequestBody Order order) {
		return returnproduct.generateReturnRequest(order);
	}

	
}
