package com.capgemini.capstore.service;

import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Order;
@Service
public interface CustomerReturnProduct {
	
	public boolean generateReturnRequest(Order order);

}
