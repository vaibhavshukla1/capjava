package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.DeliveryStatus;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.ReturnRequest;
import com.capgemini.capstore.beans.ReturnStatus;
import com.capgemini.capstore.dao.CapStoreReturnRequest;
@Service
public class CustomerReturnProductImpl implements CustomerReturnProduct {

	@Autowired
	CapStoreReturnRequest returnProduct;
	
	@Override
	public boolean generateReturnRequest(Order order) {
		if(order.getDeliveryStatus()==DeliveryStatus.Delivered) {
			ReturnRequest returnrequest = new ReturnRequest();
			returnrequest.setCustomer(order.getCustomer());
			returnrequest.setMerchant(order.getMerchant());
			returnrequest.setOrder(order);
			returnrequest.setProduct(order.getProduct());
			returnrequest.setRefundAmount(order.getTotalProductPrice());
			returnrequest.setReturnStatus(ReturnStatus.Applied);
			returnProduct.save(returnrequest);
			return true;
			
		}
		return false;
	}
	
	

}
