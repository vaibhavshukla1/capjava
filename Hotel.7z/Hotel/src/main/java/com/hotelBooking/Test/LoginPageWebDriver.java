package com.hotelBooking.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginPageWebDriver {
	
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\sts-bundle\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.get("C:\\Users\\VAIBSHUK\\Desktop\\Module-3\\Selenium\\Hotel\\WebContent\\loginpage.html");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[2]/td[2]/input")).sendKeys("capgemini");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[3]/td[2]/input")).sendKeys("capg1234");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		Thread.sleep(1000);
		
	}

}
