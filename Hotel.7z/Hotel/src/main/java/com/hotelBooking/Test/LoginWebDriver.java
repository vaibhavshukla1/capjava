package com.hotelBooking.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginWebDriver {
	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "C:\\sts-bundle\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		driver.get("C:\\Users\\VAIBSHUK\\Desktop\\Module-3\\Selenium\\Hotel\\WebContent\\login.html");
		Thread.sleep(1000);

		driver.findElement(By.id("txtFirstName")).sendKeys("Vaibhav");
		Thread.sleep(1000);

		driver.findElement(By.id("txtLastName")).sendKeys("Shukla");
		Thread.sleep(1000);

		driver.findElement(By.id("txtEmail")).sendKeys("shuklavaibhav027@gmail.com");
		Thread.sleep(1000);

		driver.findElement(By.id("txtPhone")).sendKeys("7388317917");
		Thread.sleep(1000);

		driver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea"))
				.sendKeys("uidhfuihsdfu");
		Thread.sleep(1000);

		driver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[7]/td[2]/select/option[3]")).click();
		Thread.sleep(1000);

		driver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[8]/td[2]/select/option[3]")).click();
		Thread.sleep(1000);

		driver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[10]/td[2]/select/option[6]")).click();
		Thread.sleep(1000);

		driver.findElement(By.id("txtCardholderName")).sendKeys("VAIBHAV");
		Thread.sleep(1000);

		driver.findElement(By.id("txtDebit")).sendKeys("123456789132649754");
		Thread.sleep(1000);

		driver.findElement(By.id("txtCvv")).sendKeys("123");
		Thread.sleep(1000);

		driver.findElement(By.id("txtMonth")).sendKeys("12");
		Thread.sleep(1000);

		driver.findElement(By.id("txtYear")).sendKeys("2034");
		Thread.sleep(1000);

		driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
		Thread.sleep(1000);

	}

}
