package com.hotelBooking.Test;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.hotelBooking.Beans.Login;
import com.hotelBooking.Beans.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Steps {

	WebDriver driver;
	Login login;
	LoginPage page;

	@Given("^Hotel Booking Page$")
	public void hotel_Booking_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\sts-bundle\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		login = new Login(driver);
		driver.get("C:\\Users\\VAIBSHUK\\Desktop\\Module-3\\Selenium\\Hotel\\WebContent\\login.html");
	}

	@Then("^tile varified$")
	public void tile_varified() throws Throwable {
		if (driver.getTitle().equals("Hotel Booking")) {
			System.out.println("====Hotel Booking Page Is Founded====");
		}
		Thread.sleep(1000);
	}

	@When("^first name is not entered$")
	public void first_name_is_not_entered() throws Throwable {
		login.setLastName("Shukla");
		Thread.sleep(1000);
		login.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(1000);
		login.setMobile("9598016816");
		Thread.sleep(1000);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(1000);
		login.setPune();
		Thread.sleep(1000);
		login.setMaharashtra();
		Thread.sleep(1000);
		login.setFive();
		Thread.sleep(1000);
		login.setHolderName("VAIBHAV SHUKLA");
		Thread.sleep(1000);
		login.setCardNumber("123456789101");
		Thread.sleep(1000);
		login.setCvv("123");
		Thread.sleep(1000);
		login.setExpiryMonth("10");
		Thread.sleep(1000);
		login.setExpiryYear("2034");
		Thread.sleep(1000);
	}

	@Then("^Booking fails$")
	public void booking_fails() throws Throwable {
		login.setConfirm();
		Thread.sleep(500);
		Alert alert = driver.switchTo().alert();
		alert.accept();
		Thread.sleep(500);
	}

	@When("^last name is empty$")
	public void last_name_is_empty() throws Throwable {
		login.setFirstName("Vaibhav");
		Thread.sleep(500);

		login.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(500);
		login.setMobile("9598016816");
		Thread.sleep(500);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(500);
		login.setPune();
		Thread.sleep(500);
		login.setMaharashtra();
		Thread.sleep(500);
		login.setFive();
		Thread.sleep(500);
		login.setHolderName("VAIBHAV SHUKLA");
		Thread.sleep(500);
		login.setCardNumber("123456789101");
		Thread.sleep(500);
		login.setCvv("123");
		Thread.sleep(500);
		login.setExpiryMonth("10");
		Thread.sleep(500);
		login.setExpiryYear("2034");
		Thread.sleep(500);
	}

	@When("^mobile number is empty$")
	public void mobile_number_is_empty() throws Throwable {
		login.setFirstName("Vaibhav");
		Thread.sleep(500);
		login.setLastName("Shukla");
		Thread.sleep(1000);
		login.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(500);
		login.setMobile("");
		Thread.sleep(500);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(500);
		login.setPune();
		Thread.sleep(500);
		login.setMaharashtra();
		Thread.sleep(500);
		login.setFive();
		Thread.sleep(500);
		login.setHolderName("VAIBHAV SHUKLA");
		Thread.sleep(500);
		login.setCardNumber("123456789101");
		Thread.sleep(500);
		login.setCvv("123");
		Thread.sleep(500);
		login.setExpiryMonth("10");
		Thread.sleep(500);
		login.setExpiryYear("2034");
		Thread.sleep(500);
	}

	@When("^mobile number is wrong$")
	public void mobile_number_is_wrong() throws Throwable {
		login.setFirstName("Vaibhav");
		Thread.sleep(500);
		login.setLastName("Shukla");
		Thread.sleep(1000);
		login.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(500);
		login.setMobile("abcdefghij");
		Thread.sleep(500);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(500);
		login.setPune();
		Thread.sleep(500);
		login.setMaharashtra();
		Thread.sleep(500);
		login.setFive();
		Thread.sleep(500);
		login.setHolderName("VAIBHAV SHUKLA");
		Thread.sleep(500);
		login.setCardNumber("123456789101");
		Thread.sleep(500);
		login.setCvv("123");
		Thread.sleep(500);
		login.setExpiryMonth("10");
		Thread.sleep(500);
		login.setExpiryYear("2034");
		Thread.sleep(500);
	}

	@When("^email is not entered$")
	public void email_is_not_entered() throws Throwable {
		login.setFirstName("Vaibhav");
		Thread.sleep(500);
		login.setLastName("Shukla");
		Thread.sleep(500);
		login.setMobile("9598016816");
		Thread.sleep(500);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(500);
		login.setPune();
		Thread.sleep(500);
		login.setMaharashtra();
		Thread.sleep(500);
		login.setFive();
		Thread.sleep(500);
		login.setHolderName("VAIBHAV SHUKLA");
		Thread.sleep(500);
		login.setCardNumber("123456789101");
		Thread.sleep(500);
		login.setCvv("123");
		Thread.sleep(500);
		login.setExpiryMonth("10");
		Thread.sleep(500);
		login.setExpiryYear("2034");
		Thread.sleep(500);
	}

	@When("^wrong email is entered$")
	public void wrong_email_is_entered() throws Throwable {
		login.setFirstName("Vaibhav");
		Thread.sleep(500);
		login.setLastName("Shukla");
		Thread.sleep(500);
		login.setEmail("shuklavaibhav027");
		Thread.sleep(500);
		login.setMobile("9598016816");
		Thread.sleep(500);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(500);
		login.setPune();
		Thread.sleep(500);
		login.setMaharashtra();
		Thread.sleep(500);
		login.setFive();
		Thread.sleep(500);
		login.setHolderName("VAIBHAV SHUKLA");
		Thread.sleep(500);
		login.setCardNumber("123456789101");
		Thread.sleep(500);
		login.setCvv("123");
		Thread.sleep(500);
		login.setExpiryMonth("10");
		Thread.sleep(500);
		login.setExpiryYear("2034");
		Thread.sleep(500);
	}

	@When("^city is not selected$")
	public void city_is_not_selected() throws Throwable {
		login.setFirstName("Vaibhav");
		Thread.sleep(500);
		login.setLastName("Shukla");
		Thread.sleep(500);
		login.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(500);
		login.setMobile("9598016816");
		Thread.sleep(500);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(500);
		login.setMaharashtra();
		Thread.sleep(500);
		login.setFive();
		Thread.sleep(500);
		login.setHolderName("VAIBHAV SHUKLA");
		Thread.sleep(500);
		login.setCardNumber("123456789101");
		Thread.sleep(500);
		login.setCvv("123");
		Thread.sleep(500);
		login.setExpiryMonth("10");
		Thread.sleep(500);
		login.setExpiryYear("2034");
		Thread.sleep(500);
	}

	@When("^state is not selected$")
	public void state_is_not_selected() throws Throwable {
		login.setFirstName("Vaibhav");
		Thread.sleep(500);
		login.setLastName("Shukla");
		Thread.sleep(500);
		login.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(500);
		login.setMobile("9598016816");
		Thread.sleep(500);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(500);
		login.setPune();
		Thread.sleep(500);
		login.setFive();
		Thread.sleep(500);
		login.setHolderName("VAIBHAV SHUKLA");
		Thread.sleep(500);
		login.setCardNumber("123456789101");
		Thread.sleep(500);
		login.setCvv("123");
		Thread.sleep(500);
		login.setExpiryMonth("10");
		Thread.sleep(500);
		login.setExpiryYear("2034");
		Thread.sleep(500);
	}

	@When("^card holder name not entered$")
	public void card_holder_name_not_entered() throws Throwable {
		login.setFirstName("Vaibhav");
		Thread.sleep(500);
		login.setLastName("Shukla");
		Thread.sleep(500);
		login.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(500);
		login.setMobile("9598016816");
		Thread.sleep(500);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(500);
		login.setPune();
		Thread.sleep(500);
		login.setMaharashtra();
		Thread.sleep(500);
		login.setFive();
		Thread.sleep(500);
		login.setCardNumber("123456789101");
		Thread.sleep(500);
		login.setCvv("123");
		Thread.sleep(500);
		login.setExpiryMonth("10");
		Thread.sleep(500);
		login.setExpiryYear("2034");
		Thread.sleep(500);
	}

	@When("^card number not entered$")
	public void card_number_not_entered() throws Throwable {
		login.setFirstName("Vaibhav");
		Thread.sleep(500);
		login.setLastName("Shukla");
		Thread.sleep(500);
		login.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(500);
		login.setMobile("9598016816");
		Thread.sleep(500);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(500);
		login.setPune();
		Thread.sleep(500);
		login.setMaharashtra();
		Thread.sleep(500);
		login.setFive();
		Thread.sleep(500);
		login.setHolderName("VAIBHAV SHUKLA");
		Thread.sleep(500);
		login.setCvv("123");
		Thread.sleep(500);
		login.setExpiryMonth("10");
		Thread.sleep(500);
		login.setExpiryYear("2034");
		Thread.sleep(500);
	}

	@When("^cvv not entered$")
	public void cvv_not_entered() throws Throwable {
		login.setFirstName("Vaibhav");
		Thread.sleep(500);
		login.setLastName("Shukla");
		Thread.sleep(500);
		login.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(500);
		login.setMobile("9598016816");
		Thread.sleep(500);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(500);
		login.setPune();
		Thread.sleep(500);
		login.setMaharashtra();
		Thread.sleep(500);
		login.setFive();
		Thread.sleep(500);
		login.setHolderName("VAIBHAV SHUKLA");
		Thread.sleep(500);
		login.setCardNumber("123456789101");
		Thread.sleep(500);
		login.setExpiryMonth("10");
		Thread.sleep(500);
		login.setExpiryYear("2034");
		Thread.sleep(500);
	}

	@When("^expiry month not entered$")
	public void expiry_month_not_entered() throws Throwable {
		login.setFirstName("Vaibhav");
		Thread.sleep(500);
		login.setLastName("Shukla");
		Thread.sleep(500);
		login.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(500);
		login.setMobile("9598016816");
		Thread.sleep(500);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(500);
		login.setPune();
		Thread.sleep(500);
		login.setMaharashtra();
		Thread.sleep(500);
		login.setFive();
		Thread.sleep(500);
		login.setHolderName("VAIBHAV SHUKLA");
		Thread.sleep(500);
		login.setCardNumber("123456789101");
		Thread.sleep(500);
		login.setCvv("123");
		Thread.sleep(500);
		login.setExpiryYear("2034");
		Thread.sleep(500);
	}

	@When("^expiry year not entered$")
	public void expiry_year_not_entered() throws Throwable {
		login.setFirstName("Vaibhav");
		Thread.sleep(500);
		login.setLastName("Shukla");
		Thread.sleep(500);
		login.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(500);
		login.setMobile("9598016816");
		Thread.sleep(500);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(500);
		login.setPune();
		Thread.sleep(500);
		login.setMaharashtra();
		Thread.sleep(500);
		login.setFive();
		Thread.sleep(1000);
		login.setHolderName("VAIBHAV SHUKLA");
		Thread.sleep(1000);
		login.setCardNumber("123456789101");
		Thread.sleep(1000);
		login.setCvv("123");
		Thread.sleep(1000);
		login.setExpiryMonth("10");
		Thread.sleep(1000);
	}

	@When("^all details are entered correctly$")
	public void all_details_are_entered_correctly() throws Throwable {
		login.setFirstName("Vaibhav");
		Thread.sleep(1000);
		login.setLastName("Shukla");
		Thread.sleep(1000);
		login.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(1000);
		login.setMobile("9598016816");
		Thread.sleep(1000);
		login.setAddress("117/p1/71,iehjf,ksiasdaofj,UP");
		Thread.sleep(1000);
		login.setPune();
		Thread.sleep(1000);
		login.setMaharashtra();
		Thread.sleep(1000);
		login.setFive();
		Thread.sleep(1000);
		login.setHolderName("VAIBHAV SHUKLA");
		Thread.sleep(1000);
		login.setCardNumber("123456789101");
		Thread.sleep(1000);
		login.setCvv("123");
		Thread.sleep(1000);
		login.setExpiryMonth("10");
		Thread.sleep(1000);
		login.setExpiryYear("2034");
		Thread.sleep(1000);
	}

	@Then("^Booking confirmed-$")
	public void booking_confirmed() throws Throwable {
		login.setConfirm();
		Thread.sleep(1000);
	}

	@Given("^login page$")
	public void login_page() throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:\\sts-bundle\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();

		page = new LoginPage(driver);

		driver.get("C:\\Users\\VAIBSHUK\\Desktop\\Module-3\\Selenium\\Hotel\\WebContent\\loginpage.html");

	}

	@Then("^title matched$")
	public void title_matched() throws Throwable {
		if (driver.getTitle().equals("")) {
			System.out.println("====Login Page Found====");
		}
		Thread.sleep(1000);
	}

	@When("^login user name is wrong$")
	public void login_user_name_is_wrong() throws Throwable {

		page.setName("Cap");
		Thread.sleep(1000);
		page.setPassword("capg1234");
		Thread.sleep(1000);

	}

	@Then("^login failed$")
	public void login_failed() throws Throwable {
		page.setNext();
		Alert alert = driver.switchTo().alert();
		Thread.sleep(1000);
		alert.accept();
		Thread.sleep(1000);
	}

	@When("^login password is wrong$")
	public void login_password_is_wrong() throws Throwable {
		page.setName("capgemini");
		Thread.sleep(1000);
		page.setPassword("123");
		Thread.sleep(1000);
	}

	@When("^details are not entered$")
	public void details_are_not_entered() throws Throwable {
		page.setName("");
		Thread.sleep(1000);
		page.setPassword("");
		Thread.sleep(1000);
	}

	@When("^login user name is not entered$")
	public void login_user_name_is_not_entered() throws Throwable {
		page.setPassword("capg1234");
		Thread.sleep(1000);
	}

	@When("^login password is not entered$")
	public void login_password_is_not_entered() throws Throwable {
		page.setName("capgemini");
		Thread.sleep(1000);
	}

	@Then("^login failes$")
	public void login_failes() throws Throwable {
		page.setNext();
		Thread.sleep(1000);
	}

	@When("^details are entered correctly$")
	public void details_are_entered_correctly() throws Throwable {
		page.setName("capgemini");
		Thread.sleep(1000);
		page.setPassword("capg1234");
		Thread.sleep(1000);
	}

	@Then("^login success$")
	public void login_success() throws Throwable {
		page.setNext();
		Thread.sleep(1000);
	}

}
