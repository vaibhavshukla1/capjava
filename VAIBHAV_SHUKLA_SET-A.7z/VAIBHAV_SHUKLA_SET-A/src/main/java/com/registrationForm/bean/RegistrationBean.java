package com.registrationForm.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationBean {

	// creating object of web driver
	WebDriver driver;

	// marking field of user id on page object
	@FindBy(id = "usrID")
	WebElement userId;

	// marking field of password on page object
	@FindBy(id = "pwd")
	WebElement password;

	// marking field of user name on page object
	@FindBy(id = "usrname")
	WebElement userName;

	// marking field of user address on page object
	@FindBy(id = "addr")
	WebElement address;

	// marking field of country on page object
	@FindBy(xpath = "/html/body/form/ul/li[10]/select")
	WebElement country;

	// marking field of zip code on page object
	@FindBy(xpath = "/html/body/form/ul/li[12]/input")
	WebElement zip;

	// marking field of email on page object
	@FindBy(name = "email")
	WebElement email;

	// marking field of gender male on page object
	@FindBy(xpath = "/html/body/form/ul/li[16]/input")
	WebElement male;

	// marking field of gender female on page object
	@FindBy(xpath = "/html/body/form/ul/li[17]/input")
	WebElement female;

	// marking field of language nonEnglish on page object
	@FindBy(xpath = "/html/body/form/ul/li[20]/input")
	WebElement nonEnglish;

	// marking field of about user on page object
	@FindBy(id = "desc")
	WebElement about;

	// marking field of submit on page object
	@FindBy(name = "submit")
	WebElement submit;

	// constructor using field
	public RegistrationBean(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// getter and setter
	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		submit.click();
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserId() {
		return userId;
	}

	public void setUserId(String UserId) {
		userId.sendKeys(UserId);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String Password) {
		password.sendKeys(Password);
	}

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String UserName) {
		userName.sendKeys(UserName);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String Address) {
		address.sendKeys(Address);
	}

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String Country) {
		country.sendKeys(Country);
	}

	public WebElement getZip() {
		return zip;
	}

	public void setZip(String Zip) {
		zip.sendKeys(Zip);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String Email) {
		email.sendKeys(Email);
	}

	public WebElement getMale() {
		return male;
	}

	public void setMale() {
		male.click();
	}

	public WebElement getFemale() {
		return female;
	}

	public void setFemale() {
		female.click();
	}

	public WebElement getNonEnglish() {
		return nonEnglish;
	}

	public void setNonEnglish() {
		nonEnglish.click();
	}

	public WebElement getAbout() {
		return about;
	}

	public void setAbout(String About) {
		about.sendKeys(About);
	}

}
