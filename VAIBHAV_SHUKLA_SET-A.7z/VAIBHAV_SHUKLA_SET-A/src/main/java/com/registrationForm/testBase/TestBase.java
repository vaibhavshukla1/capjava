package com.registrationForm.testBase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestBase {

	// creating object of web driver
	public static WebDriver driver;

	public static void initialization() {
		// storing driver in projectPath
		String projectPath = System.getProperty("user.dir");
		// setting property of chrome driver
		System.setProperty("webdriver.chrome.driver", projectPath + "\\driver\\chromedriver.exe");
		// setting driver as chrome driver
		driver = new ChromeDriver();
		// maximize driver window
		driver.manage().window().maximize();
		// deleting all cookies from driver
		driver.manage().deleteAllCookies();

	}

}
