package com.registrationForm.steps;

import org.openqa.selenium.Alert;

import com.registrationForm.bean.RegistrationBean;
import com.registrationForm.testBase.TestBase;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef extends TestBase {

	// creating reference to bean class
	static RegistrationBean registration;

	public StepDef() {
		super();
		setUp();
	}

	// using initialization method from TestBase class
	private void setUp() {
		initialization();
	}

	// opening registration form
	@Given("^registraton form$")
	public void registraton_form() throws Throwable {
		registration = new RegistrationBean(driver);
		String projectPath = System.getProperty("user.dir");
		driver.get(projectPath + "\\WebContent\\RegistrationForm.html");
	}

	// Verifying title of form
	@Then("^title verified$")
	public void title_verified() throws Throwable {
		if (driver.getTitle().equals("Welcome to JobsWorld")) {
			System.out.println("****REGISTRATION PAGE FOUNDED****");
		}
		Thread.sleep(500);
		driver.quit();
	}

	// opening registration form
	@Given("^registration form$")
	public void registration_form() throws Throwable {
		registration = new RegistrationBean(driver);
		String projectPath = System.getProperty("user.dir");
		driver.get(projectPath + "\\WebContent\\RegistrationForm.html");
	}

	// user id is empty
	@When("^user id is empty or wrong$")
	public void user_id_is_empty_or_wrong() throws Throwable {
		registration.setUserId("");
		Thread.sleep(500);
	}

	// alert on empty user id
	@Then("^alert box with message of wrong or empty user id occurs$")
	public void alert_box_with_message_of_wrong_or_empty_user_id_occurs() throws Throwable {
		registration.setSubmit();
		Alert alert = driver.switchTo().alert();
		Thread.sleep(500);
		if (alert.getText().equals("User Id should not be empty / length be between 5 to 12")) {
			System.out.println(alert.getText());
			alert.accept();
		}
		Thread.sleep(500);
		driver.quit();
	}

	// password is empty or wrong
	@When("^password is empty or wrong$")
	public void password_is_empty_or_wrong() throws Throwable {
		registration.setUserId("vaib123");
		Thread.sleep(500);
	}

	// alert on empty password
	@Then("^alert box with message of wrong or empty password occurs$")
	public void alert_box_with_message_of_wrong_or_empty_password_occurs() throws Throwable {
		registration.setSubmit();
		Alert alert = driver.switchTo().alert();
		Thread.sleep(500);
		if (alert.getText().equals("Password should not be empty / length be between 7 to 12")) {
			System.out.println(alert.getText());
			alert.accept();
		}
		Thread.sleep(500);
		driver.quit();
	}

	// name is empty or wrong
	@When("^name is empty or wrong$")
	public void name_is_empty_or_wrong() throws Throwable {
		registration.setUserId("vaib123");
		Thread.sleep(500);
		registration.setPassword("vaibhav1234");
		Thread.sleep(500);
		registration.setUserName("");
		Thread.sleep(500);
	}

	// alert box on empty name
	@Then("^alert box with message of wrong or empty name occurs$")
	public void alert_box_with_message_of_wrong_or_empty_name_occurs() throws Throwable {
		registration.setSubmit();
		Alert alert = driver.switchTo().alert();
		Thread.sleep(500);
		if (alert.getText().equals("Name should not be empty and must have alphabet characters only")) {
			System.out.println(alert.getText());
			Thread.sleep(500);
			alert.accept();
		}
		Thread.sleep(500);
		driver.quit();
	}

	// address is empty or wrong
	@When("^address is empty or wrong$")
	public void address_is_empty_or_wrong() throws Throwable {
		registration.setUserId("vaib123");
		Thread.sleep(500);
		registration.setPassword("vaibhav1234");
		Thread.sleep(500);
		registration.setUserName("VaibhavShukla");
		Thread.sleep(500);
	}

	// alert on empty address
	@Then("^alert box with message of wrong or empty address occurs$")
	public void alert_box_with_message_of_wrong_or_empty_address_occurs() throws Throwable {
		registration.setSubmit();
		Alert alert = driver.switchTo().alert();
		Thread.sleep(500);
		if (alert.getText().equals("User address must have alphanumeric characters only")) {
			System.out.println(alert.getText());
			alert.accept();
		}
		Thread.sleep(500);
		driver.quit();
	}

	// country is not selected
	@When("^country is empty$")
	public void country_is_empty() throws Throwable {
		registration.setUserId("vaib123");
		Thread.sleep(500);
		registration.setPassword("vaibhav1234");
		Thread.sleep(500);
		registration.setUserName("VaibhavShukla");
		Thread.sleep(500);
		registration.setAddress("117kanpur");
		Thread.sleep(500);
	}

	// alert on country
	@Then("^alert box with message of empty country occurs$")
	public void alert_box_with_message_of_empty_country_occurs() throws Throwable {
		registration.setSubmit();
		Alert alert = driver.switchTo().alert();
		Thread.sleep(500);
		if (alert.getText().equals("Select your country from the list")) {
			System.out.println(alert.getText());
			alert.accept();
		}
		Thread.sleep(500);
		driver.quit();
	}

	// wrong zip code entered
	@When("^zip code is wrong$")
	public void zip_code_is_wrong() throws Throwable {
		registration.setUserId("vaib123");
		Thread.sleep(500);
		registration.setPassword("vaibhav1234");
		Thread.sleep(500);
		registration.setUserName("VaibhavShukla");
		Thread.sleep(500);
		registration.setAddress("117kanpur");
		Thread.sleep(500);
		registration.setCountry("India");
		Thread.sleep(500);
		registration.setZip("qwe");
		Thread.sleep(500);
	}

	// alert on zip code
	@Then("^alert box with message of wrong zip code occurs$")
	public void alert_box_with_message_of_wrong_zip_code_occurs() throws Throwable {
		registration.setSubmit();
		Alert alert = driver.switchTo().alert();
		Thread.sleep(500);
		if (alert.getText().equals("ZIP code must have numeric characters only")) {
			System.out.println(alert.getText());
			alert.accept();
		}
		Thread.sleep(500);
		driver.quit();
	}

	// wrong email entered
	@When("^email is wrong$")
	public void email_is_wrong() throws Throwable {
		registration.setUserId("vaib123");
		Thread.sleep(500);
		registration.setPassword("vaibhav1234");
		Thread.sleep(500);
		registration.setUserName("VaibhavShukla");
		Thread.sleep(500);
		registration.setAddress("117kanpur");
		Thread.sleep(500);
		registration.setCountry("India");
		Thread.sleep(500);
		registration.setZip("208025");
		Thread.sleep(500);
		registration.setEmail("shuklavaibhav027");
	}

	// alert on wrong email
	@Then("^alert box with message of wrong email occurs$")
	public void alert_box_with_message_of_wrong_email_occurs() throws Throwable {
		registration.setSubmit();
		Alert alert = driver.switchTo().alert();
		Thread.sleep(500);
		if (alert.getText().equals("You have entered an invalid email address!")) {
			System.out.println(alert.getText());
			alert.accept();
		}
		Thread.sleep(500);
		driver.quit();
	}

	// gender is not selected
	@When("^gender is empty$")
	public void gender_is_empty() throws Throwable {
		registration.setUserId("vaib123");
		Thread.sleep(500);
		registration.setPassword("vaibhav1234");
		Thread.sleep(500);
		registration.setUserName("VaibhavShukla");
		Thread.sleep(500);
		registration.setAddress("117kanpur");
		Thread.sleep(500);
		registration.setCountry("India");
		Thread.sleep(500);
		registration.setZip("208025");
		Thread.sleep(500);
		registration.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(500);
	}

	// alert on gender
	@Then("^alert box with message of empty gender occurs$")
	public void alert_box_with_message_of_empty_gender_occurs() throws Throwable {
		registration.setSubmit();
		Alert alert = driver.switchTo().alert();
		Thread.sleep(500);
		if (alert.getText().equals("Please Select gender")) {
			System.out.println(alert.getText());
			alert.accept();
		}
		Thread.sleep(500);
		driver.quit();
	}

	// all data is correct
	@When("^all data entered correctly$")
	public void all_data_entered_correctly() throws Throwable {
		registration.setUserId("vaibh123");
		Thread.sleep(500);
		registration.setPassword("vaibhav1234");
		Thread.sleep(500);
		registration.setUserName("VaibhavShukla");
		Thread.sleep(500);
		registration.setAddress("117kanpur");
		Thread.sleep(500);
		registration.setCountry("India");
		Thread.sleep(500);
		registration.setZip("208025");
		Thread.sleep(500);
		registration.setEmail("shuklavaibhav027@gmail.com");
		Thread.sleep(500);
		registration.setMale();
		Thread.sleep(500);
		registration.setAbout("Hi This Is Vaibhav Shukla On Registration Form, To Register Myself For Capgemini.");
		Thread.sleep(500);
	}

	// Successfully registered
	@Then("^success of registration form$")
	public void success_of_registration_form() throws Throwable {
		registration.setSubmit();
		Thread.sleep(1000);
		Alert alert = driver.switchTo().alert();
		if (alert.getText().equals(
				"Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile")) {
			System.out.println(alert.getText());
			alert.accept();
			driver.quit();
		}
	}
}
