package com.registrationForm.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

// JUnit invokes the class
@RunWith(Cucumber.class)

// provides the same options as the cucumber command line
@CucumberOptions(features = { "src\\test\\resources\\Feature\\registration.feature" }, glue = {
		"com.registrationForm.steps" })

// Runner class to run test cases
public class TestRunner {

}
